#ifndef SERIAL_LOOP_H
#define SERIAL_LOOP_H

#include <FastLED.h>

void serialLoop(CRGB* leds);

#endif

